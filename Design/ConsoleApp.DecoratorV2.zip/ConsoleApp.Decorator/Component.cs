﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp.Decorator
{
    abstract class Component
    {
        public abstract double Operation(double Prices);
    }
}
